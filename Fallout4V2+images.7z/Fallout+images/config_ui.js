if (typeof libc_addr === 'undefined') {
  include('userland.js');
}
if (typeof lang === 'undefined') {
  include('languages.js');
}
(function () {
  log(lang.loadingConfig);
  var fs = {
    write: function (filename, content, callback) {
      var xhr = new jsmaf.XMLHttpRequest();
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && callback) {
          callback(xhr.status === 0 || xhr.status === 200 ? null : new Error('failed'));
        }
      };
      xhr.open('POST', 'file://../download0/' + filename, true);
      xhr.send(content);
    },
    read: function (filename, callback) {
      var xhr = new jsmaf.XMLHttpRequest();
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && callback) {
          callback(xhr.status === 0 || xhr.status === 200 ? null : new Error('failed'), xhr.responseText);
        }
      };
      xhr.open('GET', 'file://../download0/' + filename, true);
      xhr.send();
    }
  };
  var currentConfig = {
    autolapse: false,
    autopoop: false,
    autoclose: false,
    autoclose_delay: 0,
    music: true,
    jb_behavior: 0,
    theme: 'default'
  };

  // Store user's payloads so we don't overwrite them
  var userPayloads = [];
  var configLoaded = false;
  var jbBehaviorLabels = [lang.jbBehaviorAuto, lang.jbBehaviorNetctrl, lang.jbBehaviorLapse];
  var jbBehaviorImgKeys = ['jbBehaviorAuto', 'jbBehaviorNetctrl', 'jbBehaviorLapse'];
  function scanThemes() {
    var themes = [];
    try {
      fn.register(0x05, 'open_sys', ['bigint', 'bigint', 'bigint'], 'bigint');
      fn.register(0x06, 'close_sys', ['bigint'], 'bigint');
      fn.register(0x110, 'getdents', ['bigint', 'bigint', 'bigint'], 'bigint');
      var themesDir = '/download0/themes';
      var path_addr = mem.malloc(256);
      var buf = mem.malloc(4096);
      for (var i = 0; i < themesDir.length; i++) {
        mem.view(path_addr).setUint8(i, themesDir.charCodeAt(i));
      }
      mem.view(path_addr).setUint8(themesDir.length, 0);
      var fd = fn.open_sys(path_addr, new BigInt(0, 0), new BigInt(0, 0));
      if (!fd.eq(new BigInt(0xffffffff, 0xffffffff))) {
        var count = fn.getdents(fd, buf, new BigInt(0, 4096));
        if (!count.eq(new BigInt(0xffffffff, 0xffffffff)) && count.lo > 0) {
          var offset = 0;
          while (offset < count.lo) {
            var d_reclen = mem.view(buf.add(new BigInt(0, offset + 4))).getUint16(0, true);
            var d_type = mem.view(buf.add(new BigInt(0, offset + 6))).getUint8(0);
            var d_namlen = mem.view(buf.add(new BigInt(0, offset + 7))).getUint8(0);
            var name = '';
            for (var _i = 0; _i < d_namlen; _i++) {
              name += String.fromCharCode(mem.view(buf.add(new BigInt(0, offset + 8 + _i))).getUint8(0));
            }
            if (d_type === 4 && name !== '.' && name !== '..') {
              themes.push(name);
            }
            offset += d_reclen;
          }
        }
        fn.close_sys(fd);
      }
    } catch (e) {
      log('Theme scan failed: ' + e.message);
    }
    var idx = themes.indexOf('default');
    if (idx > 0) {
      themes.splice(idx, 1);
      themes.unshift('default');
    } else if (idx < 0) {
      themes.unshift('default');
    }
    return themes;
  }
  var availableThemes = scanThemes();
  log('Discovered themes: ' + availableThemes.join(', '));
  var themeLabels = availableThemes.map(theme => theme.charAt(0).toUpperCase() + theme.slice(1));
  var themeImgKeys = availableThemes.map(theme => 'theme' + theme.charAt(0).toUpperCase() + theme.slice(1));
  var currentButton = 0;
  var buttons = [];
  var buttonTexts = [];
  var buttonMarkers = [];
  var buttonOrigPos = [];
  var textOrigPos = [];
  var valueTexts = [];
  var normalButtonImg = 'file://../download0/img/pickr.png';
  var selectedButtonImg = 'file://../download0/img/pickr.png';
  jsmaf.root.children.length = 0;
  // Fallout 4 terminal color scheme - Dark green monochrome CRT style
  new Style({
    name: 'terminal_text',
    color: 'rgb(0, 220, 0)',
    size: 26
  });
  new Style({
    name: 'terminal_text_shadow',
    color: 'rgb(0, 0, 0)',
    size: 26
  });
  new Style({
    name: 'title',
    color: 'rgb(0, 180, 0)',
    size: 52
  });
  new Style({
    name: 'subtitle',
    color: 'rgb(0, 240, 0)',
    size: 18
  });
  new Style({
    name: 'selected',
    color: 'rgb(0, 220, 0)',
    size: 26
  });
  new Style({
    name: 'selected_shadow',
    color: 'rgb(0, 0, 0)',
    size: 26
  });
  new Style({
    name: 'prompt',
    color: 'rgb(0, 240, 0)',
    size: 22
  });
  new Style({
    name: 'help_text',
    color: 'rgb(0, 240, 0)',
    size: 18
  });
  new Style({
    name: 'dim_text',
    color: 'rgb(6, 240, 6)',
    size: 20
  });
  new Style({
    name: 'white',
    color: 'white',
    size: 24
  });
  var background = new Image({
    url: 'file:///../download0/img/FalloutBG.png',
    x: 0,
    y: 0,
    width: 1920,
    height: 1080
  });
  background.alpha = 0.6;
  jsmaf.root.children.push(background);
  
  // Terminal header section - Fallout style
  var headerLine1 = new jsmaf.Text();
  headerLine1.text = '>PIP SET >D:TERMINAL ';
  headerLine1.x = 100;
  headerLine1.y = 85;
  headerLine1.style = 'dim_text';
  jsmaf.root.children.push(headerLine1);
  
  var headerLine2 = new jsmaf.Text();
  headerLine2.text = '>PIP SET >D:"FILE/PROTECTION=OWNER -R/W READY"';
  headerLine2.x = 100;
  headerLine2.y = 105;
  headerLine2.style = 'dim_text';
  jsmaf.root.children.push(headerLine2);
  
  var headerLine3 = new jsmaf.Text();
  headerLine3.text = '>PIP SET >D:FrontEnd';
  headerLine3.x = 100;
  headerLine3.y = 125;
  headerLine3.style = 'dim_text';
  jsmaf.root.children.push(headerLine3);

  var headerLine4 = new jsmaf.Text();
  headerLine4.text = '>PIP SET >D:DevMode';
  headerLine4.x = 100;
  headerLine4.y = 150;
  headerLine4.style = 'dim_text';
  jsmaf.root.children.push(headerLine4);

  var headerLine4 = new jsmaf.Text();
  headerLine4.text = '>PIP SET >D:Fallout/Config_ui.js';
  headerLine4.x = 100;
  headerLine4.y = 175;
  headerLine4.style = 'dim_text';
  jsmaf.root.children.push(headerLine4);

  var creditText = new jsmaf.Text();
  creditText.text = 'Vue after Free 2.0';
  creditText.x = 100;
  creditText.y = 230;
  creditText.style = 'prompt';
  jsmaf.root.children.push(creditText);

  var creditText = new jsmaf.Text();
  creditText.text = 'Vue after Free 2.0';
  creditText.x = 100;
  creditText.y = 230;
  creditText.style = 'prompt';
  jsmaf.root.children.push(creditText);

  // System status display
  var statusText = new jsmaf.Text();
  statusText.text = '- VUE AFTER FREE READY -';
  statusText.x = 100;
  statusText.y = 370;
  statusText.style = 'terminal_text';
  jsmaf.root.children.push(statusText);
  
  var dividerLine = new jsmaf.Text();
  dividerLine.text = '___________________________________________________';
  dividerLine.x = 100;
  dividerLine.y = 400;
  dividerLine.style = 'terminal_text';
  jsmaf.root.children.push(dividerLine);

  var toggleOptions = [{
    key: 'autolapse',
    label: lang.autoLapse,
    imgKey: 'autoLapse',
    type: 'toggle'
  }, {
    key: 'autopoop',
    label: lang.autoPoop,
    imgKey: 'autoPoop',
    type: 'toggle'
  }, {
    key: 'autoclose',
    label: lang.autoClose,
    imgKey: 'autoClose',
    type: 'toggle'
  }, {
    key: 'music',
    label: lang.music,
    imgKey: 'music',
    type: 'toggle'
  }];
  
  var cycleOptions = [{
    key: 'jb_behavior',
    label: lang.jbBehavior,
    imgKey: 'jbBehavior',
    type: 'cycle'
  }, {
    key: 'theme',
    label: lang.theme || 'Theme',
    imgKey: 'theme',
    type: 'cycle'
  }];
  
  var configOptions = toggleOptions.concat(cycleOptions);
  var startY = 470;
  var buttonSpacing = 50;
  var leftMargin = 150;
  
  // Configuration menu title
  var section1Title = new jsmaf.Text();
  section1Title.text = 'Configuration Menu';
  section1Title.x = leftMargin;
  section1Title.y = 430;
  section1Title.style = 'terminal_text';
  jsmaf.root.children.push(section1Title);
  
  for (var i = 0; i < configOptions.length; i++) {
    var configOption = configOptions[i];
    var yPos = startY + i * buttonSpacing;
    
    // Green background panel - Fallout terminal selection box style
    var bgPanel = new Image({
      url: 'file://../download0/img/Opt_BG.png',
      x: leftMargin - 20,
      y: yPos - 12,
      width: 450,
      height: 32
    });
    bgPanel.alpha = 0.15;
    bgPanel.color = 'rgb(0, 60, 0)';
    jsmaf.root.children.push(bgPanel);
    
    // Invisible button background for hit detection
    var button = new Image({
      url: normalButtonImg,
      x: leftMargin - 50,
      y: yPos - 10,
      width: 550,
      height: 40
    });
    button.alpha = 0;
    buttons.push(button);
    jsmaf.root.children.push(button);
    
    // Selection marker (cursor) - Fallout style bracket
    var marker = new jsmaf.Text();
    marker.text = '>';
    marker.x = leftMargin - 30;
    marker.y = yPos;
    marker.style = 'selected';
    marker.visible = false;
    buttonMarkers.push(marker);
    jsmaf.root.children.push(marker);
    
    // Shadow text
    var shadowText = new jsmaf.Text();
    shadowText.text = configOption.label;
    shadowText.x = leftMargin + 3;
    shadowText.y = yPos + 3;
    shadowText.style = 'terminal_text_shadow';
    jsmaf.root.children.push(shadowText);
    
    // Menu item text
    var btnText = new jsmaf.Text();
    btnText.text = configOption.label;
    btnText.x = leftMargin;
    btnText.y = yPos;
    btnText.style = 'terminal_text';
    buttonTexts.push(btnText);
    jsmaf.root.children.push(btnText);
    
    // Value display
    var valueText = new jsmaf.Text();
    valueText.text = '';
    valueText.x = leftMargin + 250;
    valueText.y = yPos;
    valueText.style = 'terminal_text';
    valueTexts.push(valueText);
    jsmaf.root.children.push(valueText);
    
    buttonOrigPos.push({
      x: leftMargin - 50,
      y: yPos - 10
    });
    textOrigPos.push({
      x: btnText.x,
      y: btnText.y
    });
  }

  // Bottom terminal info - Fallout style
  var bottomLine1 = new jsmaf.Text();
  bottomLine1.text = '___________________________________________________';
  bottomLine1.x = 100;
  bottomLine1.y = 740;
  bottomLine1.style = 'terminal_text';
  jsmaf.root.children.push(bottomLine1);
  
  // Bottom status line
  var statusLine = new jsmaf.Text();
  statusLine.text = '>Vue after Free 2.0 compatible';
  statusLine.x = 100;
  statusLine.y = 920;
  statusLine.style = 'prompt';
  jsmaf.root.children.push(statusLine);
  
  var cursorBlink = new jsmaf.Text();
  cursorBlink.text = String.fromCharCode(9608);
  cursorBlink.x = 320;
  cursorBlink.y = 920;
  cursorBlink.style = 'terminal_text';
  jsmaf.root.children.push(cursorBlink);

  function updateHighlight() {
    for (var i = 0; i < buttonMarkers.length; i++) {
      buttonMarkers[i].visible = false;
      if (buttonTexts[i].style) {
        buttonTexts[i].style = 'terminal_text';
      }
    }
    
    if (buttonMarkers[currentButton]) {
      buttonMarkers[currentButton].visible = true;
    }
    if (buttonTexts[currentButton] && buttonTexts[currentButton].style) {
      buttonTexts[currentButton].style = 'selected';
    }
    
    prevButton = currentButton;
  }
  var prevButton = -1;
  function updateValueText(index) {
    var options = configOptions[index];
    var valueText = valueTexts[index];
    if (!options || !valueText) return;
    var key = options.key;
    if (options.type === 'toggle') {
      var value = currentConfig[key];
      valueText.text = value ? '[ON]' : '[OFF]';
    } else {
      if (key === 'jb_behavior') {
        if (useImageText) {
          valueText.url = textImageBase + jbBehaviorImgKeys[currentConfig.jb_behavior] + '.png';
        } else {
          valueText.text = jbBehaviorLabels[currentConfig.jb_behavior] || jbBehaviorLabels[0];
        }
      } else if (key === 'theme') {
        var _themeIndex = availableThemes.indexOf(currentConfig.theme);
        var _displayIndex = _themeIndex >= 0 ? _themeIndex : 0;
        if (useImageText) {
          valueText.url = textImageBase + themeImgKeys[_displayIndex] + '.png';
        } else {
          valueText.text = themeLabels[_displayIndex] || themeLabels[0];
        }
      }
    }
  }
  function saveConfig() {
    if (!configLoaded) {
      log('Config not loaded yet, skipping save');
      return;
    }
    var configData = {
      config: {
        autolapse: currentConfig.autolapse,
        autopoop: currentConfig.autopoop,
        autoclose: currentConfig.autoclose,
        autoclose_delay: currentConfig.autoclose_delay,
        music: currentConfig.music,
        jb_behavior: currentConfig.jb_behavior,
        theme: currentConfig.theme
      },
      payloads: userPayloads
    };
    var configContent = JSON.stringify(configData, null, 2);
    fs.write('config.json', configContent, function (err) {
      if (err) {
        log('ERROR: Failed to save config: ' + err.message);
      } else {
        log('Config saved successfully');
      }
    });
  }
  function loadConfig() {
    fs.read('config.json', function (err, data) {
      if (err) {
        log('ERROR: Failed to read config: ' + err.message);
        return;
      }
      try {
        var configData = JSON.parse(data || '{}');
        if (configData.config) {
          var _CONFIG = configData.config;
          currentConfig.autolapse = _CONFIG.autolapse || false;
          currentConfig.autopoop = _CONFIG.autopoop || false;
          currentConfig.autoclose = _CONFIG.autoclose || false;
          currentConfig.autoclose_delay = _CONFIG.autoclose_delay || 0;
          currentConfig.music = _CONFIG.music !== false;
          currentConfig.jb_behavior = _CONFIG.jb_behavior || 0;

          // Validate and set theme (themes are auto-discovered from directory scan)
          if (_CONFIG.theme && availableThemes.includes(_CONFIG.theme)) {
            currentConfig.theme = _CONFIG.theme;
          } else {
            log('WARNING: Theme "' + (_CONFIG.theme || 'undefined') + '" not found in available themes, using default');
            currentConfig.theme = availableThemes[0] || 'default';
          }

          // Preserve user's payloads
          if (configData.payloads && Array.isArray(configData.payloads)) {
            userPayloads = configData.payloads.slice();
          }
          for (var _i3 = 0; _i3 < configOptions.length; _i3++) {
            updateValueText(_i3);
          }
          if (currentConfig.music) {
            startBgmIfEnabled();
          } else {
            stopBgm();
          }
          configLoaded = true;
          log('Config loaded successfully');
        }
      } catch (e) {
        log('ERROR: Failed to parse config: ' + e.message);
        configLoaded = true; // Allow saving even on error
      }
    });
  }
  function handleButtonPress() {
    if (currentButton < configOptions.length) {
      var option = configOptions[currentButton];
      var key = option.key;
      if (option.type === 'cycle') {
        if (key === 'jb_behavior') {
          currentConfig.jb_behavior = (currentConfig.jb_behavior + 1) % jbBehaviorLabels.length;
          log(key + ' = ' + jbBehaviorLabels[currentConfig.jb_behavior]);
        } else if (key === 'theme') {
          var _themeIndex2 = availableThemes.indexOf(currentConfig.theme);
          var _displayIndex2 = _themeIndex2 >= 0 ? _themeIndex2 : 0;
          var nextIndex = (_displayIndex2 + 1) % availableThemes.length;
          currentConfig.theme = availableThemes[nextIndex];
          log(key + ' = ' + currentConfig.theme);
        }
      } else {
        var boolKey = key;
        currentConfig[boolKey] = !currentConfig[boolKey];
        if (boolKey === 'music') {
          if (typeof CONFIG !== 'undefined') {
            CONFIG.music = currentConfig.music;
          }
          if (currentConfig.music) {
            startBgmIfEnabled();
          } else {
            stopBgm();
          }
        }
        if (key === 'autolapse' && currentConfig.autolapse === true) {
          currentConfig.autopoop = false;
          for (var _i4 = 0; _i4 < configOptions.length; _i4++) {
            if (configOptions[_i4].key === 'autopoop') {
              updateValueText(_i4);
              break;
            }
          }
          log('autopoop disabled (autolapse enabled)');
        } else if (key === 'autopoop' && currentConfig.autopoop === true) {
          currentConfig.autolapse = false;
          for (var _i5 = 0; _i5 < configOptions.length; _i5++) {
            if (configOptions[_i5].key === 'autolapse') {
              updateValueText(_i5);
              break;
            }
          }
          log('autolapse disabled (autopoop enabled)');
        }
        log(key + ' = ' + currentConfig[boolKey]);
      }
      updateValueText(currentButton);
      saveConfig();
    }
  }
  var confirmKey = jsmaf.circleIsAdvanceButton ? 13 : 14;
  var backKey = jsmaf.circleIsAdvanceButton ? 14 : 13;
  jsmaf.onKeyDown = function (keyCode) {
    log('Key pressed: ' + keyCode);
    var totalOptions = configOptions.length;
    
    if (keyCode === 6 || keyCode === 5) {
      // Down/Right - move to next option
      currentButton = (currentButton + 1) % totalOptions;
      updateHighlight();
    } else if (keyCode === 4 || keyCode === 7) {
      // Up/Left - move to previous option
      currentButton = (currentButton - 1 + totalOptions) % totalOptions;
      updateHighlight();
    } else if (keyCode === confirmKey) {
      handleButtonPress();
    } else if (keyCode === backKey) {
      log('Restarting...');
      saveConfig();
      jsmaf.setTimeout(function () {
        debugging.restart();
      }, 100);
    }
  };
  updateHighlight();
  loadConfig();
  log(lang.configLoaded);
})();