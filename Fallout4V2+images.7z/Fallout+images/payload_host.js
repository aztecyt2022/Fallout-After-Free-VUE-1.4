(function () {
  if (typeof libc_addr === 'undefined') {
    log('Loading userland.js...');
    include('userland.js');
    log('userland.js loaded');
  } else {
    log('userland.js already loaded (libc_addr defined)');
  }
  log('Loading check-jailbroken.js...');
  include('check-jailbroken.js');
  if (typeof startBgmIfEnabled === 'function') {
    startBgmIfEnabled();
  }
  is_jailbroken = checkJailbroken();
  jsmaf.root.children.length = 0;
  // Fallout 4 terminal color scheme - Dark green monochrome CRT style
  new Style({
    name: 'terminal_text',
    color: 'rgb(0, 220, 0)',
    size: 26
  });
  new Style({
    name: 'terminal_text_shadow',
    color: 'rgb(0, 0, 0)',
    size: 26
  });
  new Style({
    name: 'title',
    color: 'rgb(0, 180, 0)',
    size: 52
  });
  new Style({
    name: 'subtitle',
    color: 'rgb(0, 240, 0)',
    size: 18
  });
  new Style({
    name: 'selected',
    color: 'rgb(0, 220, 0)',
    size: 26
  });
  new Style({
    name: 'selected_shadow',
    color: 'rgb(0, 0, 0)',
    size: 26
  });
  new Style({
    name: 'prompt',
    color: 'rgb(0, 240, 0)',
    size: 22
  });
  new Style({
    name: 'help_text',
    color: 'rgb(0, 240, 0)',
    size: 18
  });
  new Style({
    name: 'dim_text',
    color: 'rgb(6, 240, 6)',
    size: 20
  });
  new Style({
    name: 'white',
    color: 'white',
    size: 24
  });
  var currentButton = 0;
  var buttons = [];
  var buttonTexts = [];
  var buttonMarkers = [];
  var buttonOrigPos = [];
  var textOrigPos = [];
  var fileList = [];
  var normalButtonImg = 'file://../download0/img/pickr.png';
  var selectedButtonImg = 'file://../download0/img/pickr.png';
  var background = new Image({
    url: 'file:///../download0/img/FalloutBG.png',
    x: 0,
    y: 0,
    width: 1920,
    height: 1080
  });
  background.alpha = 0.6;
  jsmaf.root.children.push(background);
  
  // Terminal header section - Fallout style
  var headerLine1 = new jsmaf.Text();
  headerLine1.text = '>PIP SET >D:TERMINAL ';
  headerLine1.x = 100;
  headerLine1.y = 85;
  headerLine1.style = 'dim_text';
  jsmaf.root.children.push(headerLine1);
  
  var headerLine2 = new jsmaf.Text();
  headerLine2.text = '>PIP SET >D:"FILE/PROTECTION=OWNER -R/W READY"';
  headerLine2.x = 100;
  headerLine2.y = 105;
  headerLine2.style = 'dim_text';
  jsmaf.root.children.push(headerLine2);
  
  var headerLine3 = new jsmaf.Text();
  headerLine3.text = '>PIP SET >D:FrontEnd';
  headerLine3.x = 100;
  headerLine3.y = 125;
  headerLine3.style = 'dim_text';
  jsmaf.root.children.push(headerLine3);

  var headerLine4 = new jsmaf.Text();
  headerLine4.text = '>PIP SET >D:DevMode';
  headerLine4.x = 100;
  headerLine4.y = 150;
  headerLine4.style = 'dim_text';
  jsmaf.root.children.push(headerLine4);

  var headerLine4 = new jsmaf.Text();
  headerLine4.text = '>PIP SET >D:Fallout/Payload_host.js';
  headerLine4.x = 100;
  headerLine4.y = 175;
  headerLine4.style = 'dim_text';
  jsmaf.root.children.push(headerLine4);

  var creditText = new jsmaf.Text();
  creditText.text = 'Vue after Free 2.0';
  creditText.x = 100;
  creditText.y = 230;
  creditText.style = 'prompt';
  jsmaf.root.children.push(creditText);

  // System status display
  var statusText = new jsmaf.Text();
  statusText.text = '- VUE AFTER FREE READY -';
  statusText.x = 100;
  statusText.y = 370;
  statusText.style = 'terminal_text';
  jsmaf.root.children.push(statusText);
  
  var dividerLine = new jsmaf.Text();
  dividerLine.text = '___________________________________________________________________________________';
  dividerLine.x = 100;
  dividerLine.y = 400;
  dividerLine.style = 'terminal_text';
  jsmaf.root.children.push(dividerLine);
  fn.register(0x05, 'open_sys', ['bigint', 'bigint', 'bigint'], 'bigint');
  fn.register(0x06, 'close_sys', ['bigint'], 'bigint');
  fn.register(0x110, 'getdents', ['bigint', 'bigint', 'bigint'], 'bigint');
  fn.register(0x03, 'read_sys', ['bigint', 'bigint', 'bigint'], 'bigint');
  var scanPaths = ['/download0/payloads'];
  if (is_jailbroken) {
    scanPaths.push('/data/payloads');
    for (var i = 0; i <= 7; i++) {
      scanPaths.push('/mnt/usb' + i + '/payloads');
    }
  }
  log('Scanning paths: ' + scanPaths.join(', '));
  var path_addr = mem.malloc(256);
  var buf = mem.malloc(4096);
  for (var currentPath of scanPaths) {
    log('Scanning ' + currentPath + ' for files...');
    for (var _i = 0; _i < currentPath.length; _i++) {
      mem.view(path_addr).setUint8(_i, currentPath.charCodeAt(_i));
    }
    mem.view(path_addr).setUint8(currentPath.length, 0);
    var fd = fn.open_sys(path_addr, new BigInt(0, 0), new BigInt(0, 0));
    // log('open_sys (' + currentPath + ') returned: ' + fd.toString())

    if (!fd.eq(new BigInt(0xffffffff, 0xffffffff))) {
      var count = fn.getdents(fd, buf, new BigInt(0, 4096));
      // log('getdents returned: ' + count.toString() + ' bytes')

      if (!count.eq(new BigInt(0xffffffff, 0xffffffff)) && count.lo > 0) {
        var offset = 0;
        while (offset < count.lo) {
          var d_reclen = mem.view(buf.add(new BigInt(0, offset + 4))).getUint16(0, true);
          var d_type = mem.view(buf.add(new BigInt(0, offset + 6))).getUint8(0);
          var d_namlen = mem.view(buf.add(new BigInt(0, offset + 7))).getUint8(0);
          var name = '';
          for (var _i2 = 0; _i2 < d_namlen; _i2++) {
            name += String.fromCharCode(mem.view(buf.add(new BigInt(0, offset + 8 + _i2))).getUint8(0));
          }

          // log('Entry: ' + name + ' type=' + d_type)

          if (d_type === 8 && name !== '.' && name !== '..') {
            var lowerName = name.toLowerCase();
            if (lowerName.endsWith('.elf') || lowerName.endsWith('.bin') || lowerName.endsWith('.js')) {
              fileList.push({
                name,
                path: currentPath + '/' + name
              });
              log('Added file: ' + name + ' from ' + currentPath);
            }
          }
          offset += d_reclen;
        }
      }
      fn.close_sys(fd);
    } else {
      log('Failed to open ' + currentPath);
    }
  }
  log('Total files found: ' + fileList.length);
  var startY = 470;
  var buttonSpacing = 35;
  var columnSpacing = 350;
  var leftMargin = 100;
  
  // Create menu items with Fallout terminal style - 3 column layout
  for (var _i3 = 0; _i3 < fileList.length; _i3++) {
    var row = Math.floor(_i3 / 3);
    var col = _i3 % 3;
    var yPos = startY + row * buttonSpacing;
    var xOffset = col * columnSpacing;
    
    // Green background panel - Fallout terminal selection box style
    var bgPanel = new Image({
      url: 'file://../download0/img/Opt_BG.png',
      x: leftMargin - 20 + xOffset,
      y: yPos - 12,
      width: 300,
      height: 32
    });
    bgPanel.alpha = 0.15;
    bgPanel.color = 'rgb(0, 60, 0)';
    jsmaf.root.children.push(bgPanel);
    
    // Invisible button background for hit detection
    var button = new Image({
      url: normalButtonImg,
      x: leftMargin - 50 + xOffset,
      y: yPos - 10,
      width: 400,
      height: 40
    });
    button.alpha = 0;
    buttons.push(button);
    jsmaf.root.children.push(button);
    
    // Selection marker (cursor) - Fallout style bracket
    var marker = new jsmaf.Text();
    marker.text = '>';
    marker.x = leftMargin - 30 + xOffset;
    marker.y = yPos;
    marker.style = 'selected';
    marker.visible = false;
    buttonMarkers.push(marker);
    jsmaf.root.children.push(marker);
    
    // Shadow text
    var shadowText = new jsmaf.Text();
    shadowText.text = '[' + (_i3 + 1) + '] ' + fileList[_i3].name;
    shadowText.x = leftMargin + 3 + xOffset;
    shadowText.y = yPos + 3;
    shadowText.style = 'terminal_text_shadow';
    jsmaf.root.children.push(shadowText);
    
    // Menu item text
    var displayName = fileList[_i3].name;
    if (displayName.length > 30) {
      displayName = displayName.substring(0, 27) + '...';
    }
    var btnText = new jsmaf.Text();
    btnText.text = '[' + (_i3 + 1) + '] ' + displayName;
    btnText.x = leftMargin + xOffset;
    btnText.y = yPos;
    btnText.style = 'terminal_text';
    buttonTexts.push(btnText);
    jsmaf.root.children.push(btnText);
    
    buttonOrigPos.push({
      x: leftMargin - 50 + xOffset,
      y: yPos - 10
    });
    textOrigPos.push({
      x: btnText.x,
      y: btnText.y
    });
  }
  // Help text in Fallout terminal style - top section
  var helpBoxX = 800;
  var helpBoxY = 240;
  
  var helpBorder1 = new jsmaf.Text();
  helpBorder1.text = '________________________';
  helpBorder1.x = helpBoxX;
  helpBorder1.y = helpBoxY;
  helpBorder1.style = 'terminal_text';
  jsmaf.root.children.push(helpBorder1);
  
  var helpTitle = new jsmaf.Text();
  helpTitle.text = 'PAYLOAD MENU!';
  helpTitle.x = helpBoxX;
  helpTitle.y = helpBoxY + 30;
  helpTitle.style = 'terminal_text';
  jsmaf.root.children.push(helpTitle);
  
  var helpBorder2 = new jsmaf.Text();
  helpBorder2.text = '________________________';
  helpBorder2.x = helpBoxX;
  helpBorder2.y = helpBoxY + 55;
  helpBorder2.style = 'terminal_text';
  jsmaf.root.children.push(helpBorder2);

  var helpDpad = new jsmaf.Text();
  helpDpad.text = 'D-PAD UP/DOWN/LEFT/RIGHT: Change Selection';
  helpDpad.x = helpBoxX;
  helpDpad.y = helpBoxY + 85;
  helpDpad.style = 'help_text';
  jsmaf.root.children.push(helpDpad);
  var helpX = new jsmaf.Text();
  helpX.text = ' X: Select Option';
  helpX.x = helpBoxX;
  helpX.y = helpBoxY + 100;
  helpX.style = 'help_text';
  jsmaf.root.children.push(helpX);
  
  var helpO = new jsmaf.Text();
  helpO.text = ' O: Go Back';
  helpO.x = helpBoxX;
  helpO.y = helpBoxY + 115;
  helpO.style = 'help_text';
  jsmaf.root.children.push(helpO);
  
  var helpBorder3 = new jsmaf.Text();
  helpBorder3.text = '________________________';
  helpBorder3.x = helpBoxX;
  helpBorder3.y = helpBoxY + 125;
  helpBorder3.style = 'terminal_text';
  jsmaf.root.children.push(helpBorder3);
  
  // Bottom terminal info - Fallout style
  var bottomLine1 = new jsmaf.Text();
  bottomLine1.text = '___________________________________________________________________________________';
  bottomLine1.x = 100;
  bottomLine1.y = 880;
  bottomLine1.style = 'terminal_text';
  jsmaf.root.children.push(bottomLine1);
  
  // Bottom status line
  var statusLine = new jsmaf.Text();
  statusLine.text = '>Vue after Free 2.0 compatible';
  statusLine.x = 100;
  statusLine.y = 920;
  statusLine.style = 'prompt';
  jsmaf.root.children.push(statusLine);
  
  var cursorBlink = new jsmaf.Text();
  cursorBlink.text = String.fromCharCode(9608);
  cursorBlink.x = 320;
  cursorBlink.y = 920;
  cursorBlink.style = 'terminal_text';
  jsmaf.root.children.push(cursorBlink);
  function updateHighlight() {
    for (var i = 0; i < buttonMarkers.length; i++) {
      buttonMarkers[i].visible = false;
      if (buttonTexts[i].style) {
        buttonTexts[i].style = 'terminal_text';
      }
    }
    
    if (buttonMarkers[currentButton]) {
      buttonMarkers[currentButton].visible = true;
    }
    if (buttonTexts[currentButton] && buttonTexts[currentButton].style) {
      buttonTexts[currentButton].style = 'selected';
    }
    
    prevButton = currentButton;
  }
  var confirmKey = jsmaf.circleIsAdvanceButton ? 13 : 14;
  var backKey = jsmaf.circleIsAdvanceButton ? 14 : 13;
  jsmaf.onKeyDown = function (keyCode) {
    log('Key pressed: ' + keyCode);
    var buttonsPerRow = 3;
    if (keyCode === 6 || keyCode === 4) {
      // Down/Up - move between rows
      currentButton = keyCode === 6 ? (currentButton + buttonsPerRow) : (currentButton - buttonsPerRow);
      if (currentButton >= buttons.length) currentButton -= buttonsPerRow;
      if (currentButton < 0) currentButton += buttonsPerRow;
      updateHighlight();
    } else if (keyCode === 5 || keyCode === 7) {
      // Right/Left - move between columns
      var col = currentButton % buttonsPerRow;
      if (keyCode === 5 && col < buttonsPerRow - 1) {
        currentButton = currentButton + 1;
      } else if (keyCode === 7 && col > 0) {
        currentButton = currentButton - 1;
      }
      updateHighlight();
    } else if (keyCode === confirmKey) {
      handleButtonPress();
    } else if (keyCode === backKey) {
      log('Going back to main menu...');
      try {
        include('themes/' + (typeof CONFIG !== 'undefined' && CONFIG.theme ? CONFIG.theme : 'default') + '/main.js');
      } catch (e) {
        var err = e;
        log('ERROR loading main.js: ' + err.message);
        if (err.stack) log(err.stack);
      }
    }
  };
  function handleButtonPress() {
    if (currentButton < fileList.length) {
      var selectedEntry = fileList[currentButton];
      if (!selectedEntry) {
        log('No file selected!');
        return;
      }
      var filePath = selectedEntry.path;
      var fileName = selectedEntry.name;
      log('Selected: ' + fileName + ' from ' + filePath);
      try {
        if (fileName.toLowerCase().endsWith('.js')) {
          // Local JavaScript file case (from /download0/payloads)
          if (filePath.startsWith('/download0/')) {
            log('Including JavaScript file: ' + fileName);
            include('payloads/' + fileName);
          } else {
            // External JavaScript file case (from /data/payloads or /mnt/usbX/payloads)
            log('Reading external JavaScript file: ' + filePath);
            var p_addr = mem.malloc(256);
            for (var _i5 = 0; _i5 < filePath.length; _i5++) {
              mem.view(p_addr).setUint8(_i5, filePath.charCodeAt(_i5));
            }
            mem.view(p_addr).setUint8(filePath.length, 0);
            var _fd = fn.open_sys(p_addr, new BigInt(0, 0), new BigInt(0, 0));
            if (!_fd.eq(new BigInt(0xffffffff, 0xffffffff))) {
              var buf_size = 1024 * 1024 * 1; // 1 MiB
              var _buf = mem.malloc(buf_size);
              var read_len = fn.read_sys(_fd, _buf, new BigInt(0, buf_size));
              fn.close_sys(_fd);
              var scriptContent = '';
              var len = read_len instanceof BigInt ? read_len.lo : read_len;
              log('File read size: ' + len + ' bytes');
              for (var _i6 = 0; _i6 < len; _i6++) {
                scriptContent += String.fromCharCode(mem.view(_buf).getUint8(_i6));
              }
              log('Executing via eval()...');
              // eslint-disable-next-line no-eval
              eval(scriptContent);
            } else {
              log('ERROR: Could not open file for reading!');
            }
          }
        } else {
          log('Loading binloader.js...');
          include('binloader.js');
          log('binloader.js loaded successfully');
          log('Initializing binloader...');
          var {
            bl_load_from_file
          } = binloader_init();
          log('Loading payload from: ' + filePath);
          bl_load_from_file(filePath);
        }
      } catch (e) {
        var err = e;
        log('ERROR: ' + err.message);
        if (err.stack) log(err.stack);
      }
    }
  }
  updateHighlight();
  log('Interactive UI loaded!');
  log('Total elements: ' + jsmaf.root.children.length);
  log('Buttons: ' + buttons.length);
  log('Use arrow keys to navigate, Enter/X to select');
})();