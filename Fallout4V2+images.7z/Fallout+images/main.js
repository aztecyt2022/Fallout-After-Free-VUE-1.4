(function () {
  include('languages.js');
  log(lang.loadingMainMenu);
  var currentButton = 0;
  var buttons = [];
  var buttonTexts = [];
  var buttonMarkers = [];
  var buttonOrigPos = [];
  var textOrigPos = [];
  var normalButtonImg = 'file://../download0/img/Opt_BG.png';
  var selectedButtonImg = 'file://../download0/img/Opt_BG.png';
  jsmaf.root.children.length = 0;
  // Fallout 4 terminal color scheme - Dark green monochrome CRT style
  new Style({
    name: 'terminal_text',
    color: 'rgb(0, 220, 0)',
    size: 26
  });
  new Style({
    name: 'terminal_text_shadow',
    color: 'rgb(0, 0, 0)',
    size: 26
  });
  new Style({
    name: 'title',
    color: 'rgb(0, 180, 0)',
    size: 52
  });
  new Style({
    name: 'subtitle',
    color: 'rgb(0, 240, 0)',
    size: 18
  });
  new Style({
    name: 'selected',
    color: 'rgb(0, 220, 0)',
    size: 26
  });
  new Style({
    name: 'selected_shadow',
    color: 'rgb(0, 0, 0)',
    size: 26
  });
  new Style({
    name: 'prompt',
    color: 'rgb(0, 240, 0)',
    size: 22
  });
  new Style({
    name: 'help_text',
    color: 'rgb(0, 240, 0)',
    size: 18
  });
  new Style({
    name: 'dim_text',
    color: 'rgb(6, 240, 6)',
    size: 20
  });
  new Style({
    name: 'white',
    color: 'white',
    size: 24
  });
  if (typeof startBgmIfEnabled === 'function') {
    startBgmIfEnabled();
  }
  var background = new Image({
    url: 'file:///../download0/img/FalloutBG.png',
    x: 0,
    y: 0,
    width: 1920,
    height: 1080
  });
  background.alpha = 0.6;
  jsmaf.root.children.push(background);
  
  // Terminal header section - Fallout style
  var headerLine1 = new jsmaf.Text();
  headerLine1.text = '>PIP SET >D:TERMINAL ';
  headerLine1.x = 100;
  headerLine1.y = 85;
  headerLine1.style = 'dim_text';
  jsmaf.root.children.push(headerLine1);
  
  var headerLine2 = new jsmaf.Text();
  headerLine2.text = '>PIP SET >D:"FILE/PROTECTION=OWNER -R/W READY"';
  headerLine2.x = 100;
  headerLine2.y = 105;
  headerLine2.style = 'dim_text';
  jsmaf.root.children.push(headerLine2);
  
  var headerLine3 = new jsmaf.Text();
  headerLine3.text = '>PIP SET >D:FrontEnd';
  headerLine3.x = 100;
  headerLine3.y = 125;
  headerLine3.style = 'dim_text';
  jsmaf.root.children.push(headerLine3);

  var headerLine4 = new jsmaf.Text();
  headerLine4.text = '>PIP SET >D:DevMode';
  headerLine4.x = 100;
  headerLine4.y = 150;
  headerLine4.style = 'dim_text';
  jsmaf.root.children.push(headerLine4);

  var headerLine4 = new jsmaf.Text();
  headerLine4.text = '>PIP SET >D:Fallout/Main.js';
  headerLine4.x = 100;
  headerLine4.y = 175;
  headerLine4.style = 'dim_text';
  jsmaf.root.children.push(headerLine4);

  var creditText = new jsmaf.Text();
  creditText.text = 'Vue after Free 2.0';
  creditText.x = 100;
  creditText.y = 230;
  creditText.style = 'prompt';
  jsmaf.root.children.push(creditText);

  // System status display
  var statusText = new jsmaf.Text();
  statusText.text = '- VUE AFTER FREE READY -';
  statusText.x = 100;
  statusText.y = 370;
  statusText.style = 'terminal_text';
  jsmaf.root.children.push(statusText);
  
  var dividerLine = new jsmaf.Text();
  dividerLine.text = '___________________________________________________________________________________';
  dividerLine.x = 100;
  dividerLine.y = 400;
  dividerLine.style = 'terminal_text';
  jsmaf.root.children.push(dividerLine);
  
  var menuOptions = [{
    label: lang.jailbreak,
    script: 'loader.js',
    imgKey: 'jailbreak'
  }, {
    label: lang.payloadMenu,
    script: 'payload_host.js',
    imgKey: 'payloadMenu'
  }, {
    label: lang.config,
    script: 'config_ui.js',
    imgKey: 'config'
  }];
  
  var startY = 470;
  var buttonSpacing = 70;
  var leftMargin = 150;
  
  // Create menu items with Fallout terminal style
  for (var i = 0; i < menuOptions.length; i++) {
    var yPos = startY + i * buttonSpacing;
    
    // Green background panel - Fallout terminal selection box style
    var bgPanel = new Image({
      url: 'file://../download0/img/Opt_BG.png',
      x: leftMargin - 20,
      y: yPos - 12,
      width: 700,
      height: 50
    });
    bgPanel.alpha = 0.15;
    bgPanel.color = 'rgb(0, 60, 0)';
    jsmaf.root.children.push(bgPanel);
    
    // Invisible button background for hit detection
    var button = new Image({
      url: normalButtonImg,
      x: leftMargin - 50,
      y: yPos - 10,
      width: 1100,
      height: 60
    });
    button.alpha = 0;
    buttons.push(button);
    jsmaf.root.children.push(button);
    
    // Selection marker (cursor) - Fallout style bracket
    var marker = new jsmaf.Text();
    marker.text = '>';
    marker.x = leftMargin - 30;
    marker.y = yPos;
    marker.style = 'selected';
    marker.visible = false;
    buttonMarkers.push(marker);
    jsmaf.root.children.push(marker);
    
    // Shadow text
    var shadowText = new jsmaf.Text();
    shadowText.text = '[' + (i + 1) + '] ' + menuOptions[i].label;
    shadowText.x = leftMargin + 3;
    shadowText.y = yPos + 3;
    shadowText.style = 'terminal_text_shadow';
    jsmaf.root.children.push(shadowText);
    
    // Menu item text
    var btnText;
    if (typeof useImageText !== 'undefined' && useImageText) {
      btnText = new Image({
        url: textImageBase + menuOptions[i].imgKey + '.png',
        x: leftMargin + 20,
        y: yPos - 5,
        width: 300,
        height: 50
      });
    } else {
      btnText = new jsmaf.Text();
      btnText.text = '[' + (i + 1) + '] ' + menuOptions[i].label;
      btnText.x = leftMargin;
      btnText.y = yPos;
      btnText.style = 'terminal_text';
    }
    buttonTexts.push(btnText);
    jsmaf.root.children.push(btnText);
    
    buttonOrigPos.push({
      x: leftMargin - 50,
      y: yPos - 10
    });
    textOrigPos.push({
      x: btnText.x,
      y: btnText.y
    });
  }
  
  // Exit option
  var exitY = startY + menuOptions.length * buttonSpacing + 40;
  
  var exitBgPanel = new Image({
    url: 'file://../download0/img/Opt_BG.png',
    x: leftMargin - 20,
    y: exitY - 12,
    width: 700,
    height: 50
  });
  exitBgPanel.alpha = 0.15;
  exitBgPanel.color = 'rgb(0, 60, 0)';
  jsmaf.root.children.push(exitBgPanel);
  
  var exitButton = new Image({
    url: normalButtonImg,
    x: leftMargin - 50,
    y: exitY - 10,
    width: 1100,
    height: 60
  });
  exitButton.alpha = 0;
  buttons.push(exitButton);
  jsmaf.root.children.push(exitButton);
  
  var exitMarker = new jsmaf.Text();
  exitMarker.text = '>';
  exitMarker.x = leftMargin - 30;
  exitMarker.y = exitY;
  exitMarker.style = 'selected';
  exitMarker.visible = false;
  buttonMarkers.push(exitMarker);
  jsmaf.root.children.push(exitMarker);
  
  // Exit shadow text
  var exitShadow = new jsmaf.Text();
  exitShadow.text = '[0] ' + lang.exit;
  exitShadow.x = leftMargin + 3;
  exitShadow.y = exitY + 3;
  exitShadow.style = 'terminal_text_shadow';
  jsmaf.root.children.push(exitShadow);
  
  // Exit main text
  var exitText;
  if (typeof useImageText !== 'undefined' && useImageText) {
    exitText = new Image({
      url: textImageBase + 'exit.png',
      x: leftMargin + 20,
      y: exitY - 5,
      width: 300,
      height: 50
    });
  } else {
    exitText = new jsmaf.Text();
    exitText.text = '[0] ' + lang.exit;
    exitText.x = leftMargin;
    exitText.y = exitY;
    exitText.style = 'terminal_text';
  }
  buttonTexts.push(exitText);
  jsmaf.root.children.push(exitText);
  
  buttonOrigPos.push({
    x: leftMargin - 50,
    y: exitY - 10
  });
  textOrigPos.push({
    x: exitText.x,
    y: exitText.y
  });
  
  // Bottom terminal info - Fallout style
  var bottomLine1 = new jsmaf.Text();
  bottomLine1.text = '___________________________________________________________________________________';
  bottomLine1.x = 100;
  bottomLine1.y = 880;
  bottomLine1.style = 'terminal_text';
  jsmaf.root.children.push(bottomLine1);
  
  // Help text in Fallout terminal style - right side box
  var helpBoxX = 870;
  var helpBoxY = 550;
  
  var helpBorder1 = new jsmaf.Text();
  helpBorder1.text = '________________________';
  helpBorder1.x = helpBoxX;
  helpBorder1.y = helpBoxY;
  helpBorder1.style = 'terminal_text';
  jsmaf.root.children.push(helpBorder1);
  
  var helpTitle = new jsmaf.Text();
  helpTitle.text = 'VUE MENU!';
  helpTitle.x = helpBoxX;
  helpTitle.y = helpBoxY + 30;
  helpTitle.style = 'terminal_text';
  jsmaf.root.children.push(helpTitle);
  
  var helpBorder2 = new jsmaf.Text();
  helpBorder2.text = '________________________';
  helpBorder2.x = helpBoxX;
  helpBorder2.y = helpBoxY + 55;
  helpBorder2.style = 'terminal_text';
  jsmaf.root.children.push(helpBorder2);

  var helpDpad = new jsmaf.Text();
  helpDpad.text = 'D-PAD UP/DOWN: Change Selection';
  helpDpad.x = helpBoxX;
  helpDpad.y = helpBoxY + 85;
  helpDpad.style = 'help_text';
  jsmaf.root.children.push(helpDpad);
  var helpX = new jsmaf.Text();
  helpX.text = ' X: Select Option';
  helpX.x = helpBoxX;
  helpX.y = helpBoxY + 100;
  helpX.style = 'help_text';
  jsmaf.root.children.push(helpX);
  
  var helpO = new jsmaf.Text();
  helpO.text = ' O: Go Back';
  helpO.x = helpBoxX;
  helpO.y = helpBoxY + 115;
  helpO.style = 'help_text';
  jsmaf.root.children.push(helpO);
  
  var helpBorder3 = new jsmaf.Text();
  helpBorder3.text = '________________________';
  helpBorder3.x = helpBoxX;
  helpBorder3.y = helpBoxY + 125;
  helpBorder3.style = 'terminal_text';
  jsmaf.root.children.push(helpBorder3);
  
  // Bottom status line
  var statusLine = new jsmaf.Text();
  statusLine.text = '>Vue after Free 2.0 compatible';
  statusLine.x = 100;
  statusLine.y = 920;
  statusLine.style = 'prompt';
  jsmaf.root.children.push(statusLine);
  
  var cursorBlink = new jsmaf.Text();
  cursorBlink.text = String.fromCharCode(9608);
  cursorBlink.x = 320;
  cursorBlink.y = 920;
  cursorBlink.style = 'terminal_text';
  jsmaf.root.children.push(cursorBlink);
  function updateHighlight() {
    for (var i = 0; i < buttonMarkers.length; i++) {
      buttonMarkers[i].visible = false;
      if (buttonTexts[i].style) {
        buttonTexts[i].style = 'terminal_text';
      }
    }
    
    if (buttonMarkers[currentButton]) {
      buttonMarkers[currentButton].visible = true;
    }
    if (buttonTexts[currentButton] && buttonTexts[currentButton].style) {
      buttonTexts[currentButton].style = 'selected';
    }
    
    prevButton = currentButton;
  }
  function handleButtonPress() {
    if (currentButton === buttons.length - 1) {
      log('>> TERMINATING PROCESS...');
      try {
        include('includes/kill_vue.js');
      } catch (e) {
        log('>> ERROR during exit: ' + e.message);
        if (e.stack) log(e.stack);
      }
      jsmaf.exit();
    } else if (currentButton < menuOptions.length) {
      var selectedOption = menuOptions[currentButton];
      if (!selectedOption) return;
      if (selectedOption.script === 'loader.js') {
        jsmaf.onKeyDown = function () {};
      }
      log('>> LOADING MODULE: ' + selectedOption.script);
      try {
        if (selectedOption.script.includes('loader.js')) {
          include(selectedOption.script);
        } else {
          include('themes/' + (typeof CONFIG !== 'undefined' && CONFIG.theme ? CONFIG.theme : 'default') + '/' + selectedOption.script);
        }
      } catch (e) {
        log('>> ERROR loading ' + selectedOption.script + ': ' + e.message);
        if (e.stack) log(e.stack);
      }
    }
  }
  jsmaf.onKeyDown = function (keyCode) {
    if (keyCode === 6 || keyCode === 5) {
      currentButton = (currentButton + 1) % buttons.length;
      updateHighlight();
    } else if (keyCode === 4 || keyCode === 7) {
      currentButton = (currentButton - 1 + buttons.length) % buttons.length;
      updateHighlight();
    } else if (keyCode === 14) {
      handleButtonPress();
    }
  };
  updateHighlight();
  log('>> TERMINAL INTERFACE LOADED');
})();